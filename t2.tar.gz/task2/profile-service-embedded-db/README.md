Profile service embedded database will have the same function with profile service.
The only difference's the different backend database.
Embedded database version will be using embedded h2 database.
To switch from h2 to MySQL. We only need to modify the application.properties and pom.xml file.